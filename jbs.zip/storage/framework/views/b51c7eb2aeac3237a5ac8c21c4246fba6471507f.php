<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <title>Seguridad JBS</title>
        <style>
            .active-menu{
                font-weight: bold;                
                color: green;                
            }
        </style>
    </head>
    <body>
        <div id="app">
            <my-app></my-app>
        </div>   
    </body>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>    
</html>
<?php /**PATH /var/www/html/resources/views/index.blade.php ENDPATH**/ ?>